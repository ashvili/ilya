from .module import NeuralNetwork
from .train import train
from .predict import predict
